package com.org.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.org.hbms.dao.IQueryMapper;
import com.org.hbms.util.DBConnection;
import com.org.hbms.bean.HBMSbean;
import com.org.hbms.exception.HBMSException;

public class HBMSDaoImpl implements IHBMSDao{

	@Override
	public int registerUser(HBMSbean b) throws HBMSException{
			Connection conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			try {
				s=conn.prepareStatement(IQueryMapper.userIdQuery);
				ResultSet re=s.executeQuery();
				re.next();
				int id=re.getInt(1);
				String userID=Integer.toString(id);
				s = conn.prepareStatement(IQueryMapper.userRegisterQuery);
				s.setString(1,userID);
				s.setString(2,b.getPassword());
				s.setString(3,b.getRole());
				s.setString(4,b.getUserName());
				s.setString(5,b.getMobileNo());
				s.setString(6,b.getPhone());
				s.setString(7,b.getAddress());
				s.setString(8,b.getEmail());
				int c=s.executeUpdate();
				return id;
			} catch (SQLException e) {
				throw new HBMSException("problem in connecting to database");
			}
	}

	@Override
	public boolean validateUserLogin(String username, String password) throws HBMSException{
		Connection conn=DBConnection.getInstance().getConnection();
		PreparedStatement s;
		try {
			s = conn.prepareStatement(IQueryMapper.userValidQuery);
			s.setString(1,username);
			s.setString(2,password);
			ResultSet r=s.executeQuery();
			if(r.next())
			{
				int count=r.getInt(1);
				System.out.println(count);
				if(count>0)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} catch (SQLException e) {
			throw new HBMSException("problem in connecting to database");
		}
		
	}

	@Override
	public StringBuilder getHotelDetails() throws HBMSException {
		Connection conn=DBConnection.getInstance().getConnection();
		try {
			PreparedStatement s=conn.prepareStatement(IQueryMapper.hotelDetailsQuery);
			ResultSet st=s.executeQuery();
			StringBuilder details=new StringBuilder("");
			while(st.next())
			{
				details.append(st.getString(1)+" ");
				details.append(st.getString(2)+" ");
				details.append(st.getString(3)+" ");
				details.append(st.getString(4)+" ");
				details.append(st.getString(5)+" ");
				details.append(st.getInt(6)+" ");
				details.append(st.getString(7)+" ");
				details.append(st.getString(8)+" ");
				details.append(st.getString(9)+" ");
				details.append(st.getString(10)+" ");
				details.append(st.getString(11)+" ");
				details.append("\n");
			}
			return details;
		} 
		catch (SQLException e) {
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public HBMSbean getUserDetails(String username, String password) throws HBMSException {
		Connection conn=DBConnection.getInstance().getConnection();
		HBMSbean user=null;
		try {
			PreparedStatement s=conn.prepareStatement(IQueryMapper.getRoleQuery);
			s.setString(1,username);
			s.setString(2,password);
			ResultSet rs=s.executeQuery();
			if(rs.next())
			{
				System.out.println("hello");
				user=new HBMSbean();
				user.setUserId(rs.getString(1));
				user.setPassword(rs.getString(2));
				user.setRole(rs.getString(3));
				user.setUserName(rs.getString(4));
				user.setMobileNo(rs.getString(5));
				user.setPhone(rs.getString(6));
				user.setAddress(rs.getString(7));
				user.setEmail(rs.getString(8));
			}
			return user;
		} catch (SQLException e) {
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public StringBuilder displayRooms(String hotel_id) throws HBMSException {
		Connection conn=DBConnection.getInstance().getConnection();
		try {
			PreparedStatement s=conn.prepareStatement(IQueryMapper.displayRoomQuery);
			ResultSet st=s.executeQuery();
			StringBuilder details=new StringBuilder("");
			while(st.next())
			{
				if(st.getBoolean(6))
				{
					details.append(st.getString(1)+" ");
					details.append(st.getString(2)+" ");
					details.append(st.getString(3)+" ");
					details.append(st.getString(4)+" ");
					details.append(st.getInt(5)+" ");
					details.append(st.getBoolean(6)+" ");
					details.append("\n");
				}
			}
			return details;
		}
		catch(SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public boolean isValidHotelId(String hotel_id) throws HBMSException {
		Connection conn=DBConnection.getInstance().getConnection();
		try {
			PreparedStatement s=conn.prepareStatement(IQueryMapper.validHotelQuery);
			s.setString(1,hotel_id);
			ResultSet st=s.executeQuery();
			if(st.next())
			{
				int count=st.getInt(1);
				if(count>0)
				{
					return true;
				}
			}
			return false;
		}
		catch(SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

}
