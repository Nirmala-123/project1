package com.org.hbms.pi;

import java.sql.SQLException;
import java.util.Scanner;

import com.org.hbms.bean.HBMSbean;
import com.org.hbms.exception.HBMSException;
import com.org.hbms.service.HBMSserviceImpl;
import com.org.hbms.service.IHBMSservice;

public final class HBMSMain {

	public static void main(String[] args) throws HBMSException, SQLException {
		String rUserName,rPassword,rUserId,rMobileNo,rPhone,rRole,rEmail,rAddress;
		Scanner sc=new Scanner(System.in);
		HBMSbean b=new HBMSbean();
		IHBMSservice s1=new HBMSserviceImpl();
		System.out.println("Welcome to hotel bookings\n\n");
		int ch;
		String username,password;
		do
		{
			System.out.println("enter your choice");
			System.out.println("1.user login \n 2.admin login \n 3.user registration \n 4.exit");
			ch=sc.nextInt();
			if(ch==1)
			{
				System.out.println("please enter login credentials");
				System.out.println("user name:");
				username=sc.next();
				System.out.println("enter password:");
				password=sc.next();
				if(s1.validateUserLogin(username,password))
				{
					System.out.println("logged in sucessfully");
					HBMSbean user=s1.getUserDetails(username,password);
					System.out.println("hotels and their descriptions");
					displayHotels(user);			
				}
				else
				{
					System.out.println("invalid credentials");
				}
			}
			else if(ch==2)
			{
				System.out.println("please enter login credentials");
				System.out.println("username:");
				username=sc.next();
				System.out.println("password:");
				password=sc.next();
				if(s1.validateAdminLogin(username,password))
				{
					displayAdminMenu();
				}
				else
				{
					System.out.println("invalid credentials");
				}
			}
			else if(ch==3)
			{
				System.out.println("fill out the following fields\n");
				System.out.println("enter password:");
				rPassword=sc.next();
				while(true)
				{
					if(s1.isValidPassword(rPassword))
					{
						break;
					}
					else
					{
						System.out.println("enter valid password:");
						rPassword=sc.next();
					}
				}
				System.out.println("enter user name:");
				rUserName=sc.next();
				System.out.println("enter mobile number:");
				rMobileNo=sc.next();
				System.out.println("enter phone number");
				rPhone=sc.next();
				System.out.println("enter your address:");
				rAddress=sc.next();
				System.out.println("enter your mail id:");
				rEmail=sc.next();
				b.setPassword(rPassword);
				b.setUserName(rUserName);
				b.setMobileNo(rMobileNo);
				b.setPhone(rPhone);
				b.setRole("user");
				b.setAddress(rAddress);
				b.setEmail(rEmail);
				int Id=s1.registerUser(b);
				String userId=Integer.toString(Id);
				b.setUserId(userId);
				System.out.println("you have registeres sucessfully with registration ID:"+b.getUserId());
			}
			else if(ch==4)
			{
				break;
			}
			else
			{
				System.out.println("please enter valid choice");
			}
		}while(ch!=4);
	}

	private static void displayAdminMenu() {
		int op,choice;
		do
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("enter your choice");
			System.out.println("1.hotel management\n2.room management\n3.exit");
			choice=sc.nextInt();
			if(choice==1)
			{
				do
				{
					System.out.println("enter operation to perform");
					System.out.println("1.add hotel\n2.delete hotel\n3.exit");
					op=sc.nextInt();
					if(op==1)
					{
						
						System.out.println("fill the following details");
						
					}
					else if(op==2)
					{
						
					}
					else if(op==3)
					{
						break;
					}
					else
					{
						System.out.println("please enter valid choice");
					}
				}while(op!=3);
			}
			else if(choice==2)
			{
				do
				{
					System.out.println("enter operation to perform");
					System.out.println("1.add room\n2.delete room\n3.exit");
					op=sc.nextInt();
					if(op==1)
					{
						
					}
					else if(op==2)
					{
						
					}
					else if(op==3)
					{
						break;
					}
					else
					{
						System.out.println("please enter valid choice");
					}
				}while(op!=3);
			}
			else if(choice==3)
			{
				break;
			}
			else
			{
				System.out.println("please enter valid choice");
			}
		}while(choice!=3);
		
	}

	private static void displayHotels(HBMSbean user) {
		if(user.getRole().equals("user"))
		{
			IHBMSservice s1=new HBMSserviceImpl();
			Scanner sc=new Scanner(System.in);
			System.out.println("select hotel from the below list");
			try
			{
				StringBuilder hotelDetails=s1.getHotelDetails();
				System.out.println(hotelDetails);
				System.out.println("enter hotel id to view rooms");
				String hotel_id=sc.next();
				while(true)
				{
					if(s1.isValidHotelId(hotel_id))
					{
						StringBuilder roomDetails=s1.displayRooms(hotel_id);
						System.out.println("select room from the below list");
						System.out.println(roomDetails);
						System.out.println("enter room id to go to booking page");
						String roomId=sc.next();
						break;
					}
				}
			}
			catch (HBMSException e) {
					System.out.println(e.getMessage());
			}
		}
		else
		{
			
		}
		
	}

}
