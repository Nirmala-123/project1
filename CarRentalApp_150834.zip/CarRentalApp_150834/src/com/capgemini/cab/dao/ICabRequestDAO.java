package com.capgemini.cab.dao;
import com.capgemini.cab.exception.InvalidRequestException;
import com.capgemini.cabs.bean.*;

public interface ICabRequestDAO
{

public int addCabRequestDetails(CabRequest cabRequest) throws InvalidRequestException;

boolean getRequestDetails(int requestId) throws InvalidRequestException;


}
