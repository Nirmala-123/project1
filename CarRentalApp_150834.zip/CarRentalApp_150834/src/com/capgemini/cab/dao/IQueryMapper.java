package com.capgemini.cab.dao;

public class IQueryMapper {
	public static final String VIEWPLANS="select * from cab_request";
	public static final String GETPINCODE="select cab_number from cab_request where pincode=?";
	public static final String CHECKTABLE="Select count(*) from tab where tname='CABINFO'";
	public static final String GENERATESEQUENCE="Select rech_Id.nextval from dual";
	public static final String GETCUSTOMER="select count(*) from plans where customer_name=?";
	public static final String INSERTQUERY="insert into cabinfo values(?,?,?,?,?,?,default sysDate)";
	public static final String CHECKREQUESTID="select count(*) from cabinfo where rechId=?";
	public static final String GETDETAILS="Select * from cabinfo where request_id=?";
	
}
