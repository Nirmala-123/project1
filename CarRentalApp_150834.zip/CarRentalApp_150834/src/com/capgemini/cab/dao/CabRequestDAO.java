package com.capgemini.cab.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.capgemini.cabs.bean.*;
import com.capgemini.cab.dao.CabRequestDAO;
import com.capgemini.cab.dao.IQueryMapper;
import com.capgemini.cab.exception.InvalidRequestException;
import com.capgemini.cab.util.DBConnection;
import com.capgemini.cab.exception.*;
import com.capgemini.cabs.bean.*;
import com.capgemini.cab.exception.*;


public class CabRequestDAO implements ICabRequestDAO{
	
	Logger logger=Logger.getRootLogger();
	public CabRequestDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");

	}
	
		/*******************************************************************************************************
		 - Function Name	:	addUserDetails(RechargeBean b1)
		 - Input Parameters	:	RechargeBean b1
		 - Return Type		:	void
		 - Throws			:  	InvalidRecharge
		 - Author			:	CAPGEMINI
		 - Creation Date	:	18/06/2018
		 - Description		:	Performing CabRequest and adding user details to database
		 ********************************************************************************************************/

		@Override
		public int addCabRequestDetails(CabRequest s1) throws InvalidRequestException {
			try {
				Connection conn = DBConnection.getInstance().getConnection();
				
			java.sql.Statement ss=conn.createStatement();
			ResultSet rs=ss.executeQuery(IQueryMapper.CHECKTABLE);
			rs.next();
			String sr=rs.getString(1);
			if(Integer.parseInt(sr)<=0)
				creation();
			java.sql.Statement ss1=conn.createStatement();
			ResultSet rst=ss1.executeQuery(IQueryMapper.GENERATESEQUENCE);
			rst.next();
			String str=rst.getString(1);
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.GETCUSTOMER);
			Object b1;
				ResultSet rs1=pst.executeQuery();
			rs1.next();
			int count=Integer.parseInt(rs1.getString(1));
			if(count<=0)
				s1.setRequestStatus("Failed");
			else
				s1.setRequestStatus("Success");
			PreparedStatement s=conn.prepareStatement(IQueryMapper.INSERTQUERY);
			s.setString(1,s1.getRequestId());
			s.setString(2,s1.getCustomerName());
			s.setString(3,s1.getCustomerMobileNum());
			s.setString(4,s1.getRequestStatus());
			s.setLong(5,s1.getPincode());
			s.setString(6,s1.getAddressofPickup());
			s.executeUpdate();
			s.close();
			pst.close();
			ss.close();
			rst.close();
			conn.close();
			}
			catch(SQLException e)
			{
				logger.error(e.getMessage());
				throw new InvalidRequestException("Error in closing db connection");		
			}
			
		}
		/*******************************************************************************************************
		 - Function Name	:	getRequestDetailsUserDetails(String rechId,RechargeBean bean)
		 - Input Parameters	:	String rechId,RechargeBean b1
		 - Return Type		:	boolean
		 - Throws			:  	InvalidRequestException
		 - Author			:	CAPGEMINI
		 - Creation Date	:	18/06/2018
		 - Description		:	retrieve user details from database
		 ********************************************************************************************************/
		@Override
		public boolean getRequestDetails(String requestId,CabRequest bean) throws InvalidRequestException{
			try {
				Connection con = DBConnection.getInstance().getConnection();
			PreparedStatement pst=con.prepareStatement(IQueryMapper.CHECKREQUESTID);
			pst.setString(1,rechId);
			ResultSet rs1=pst.executeQuery();
			rs1.next();
			int count=Integer.parseInt(rs1.getString(1));
			if(count<=0)
			{
				throw new InvalidRequestId();
			}
			else
			{
				PreparedStatement ps=con.prepareStatement(IQueryMapper.GETDETAILS);
				ps.setString(1,requestId);
				ResultSet rs=ps.executeQuery();
				while(rs.next())
				{
			
					bean.setRequestId(rs.getString(6));
					bean.setCustomerName(rs.getString(2));
					bean.setCustomerMobileNum(rs.getString(3));
					bean.setRequestStatus(rs.getString(4));
					bean.setPincode(rs.getLong(5));
					bean.setAddressofPickup(rs.getString(20));
				}
				ps.close();
				rs.close();
				con.close();
				return false;
			}
			}
			catch(InvalidRequestId r)
			{
				logger.error("Invalid RechargeId");
				System.out.println(r);
				return true;
			}
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new InvalidRequestException("Error in closing db connection");

			}
		}
		
		/*******************************************************************************************************
		 - Function Name	:	creation()
		 - Input Parameters	:	
		 - Return Type		:	void
		 - Throws			: InvalidRequestException
		 - Author			:	CAPGEMINI
		 - Creation Date	:	18/06/2018
		 - Description		:	create Cab_Request table and rech_Id sequence 
		 ********************************************************************************************************/
		public void creation() throws InvalidRequestException
		{
			try {
			Connection conn = DBConnection.getInstance().getConnection();		
			PreparedStatement s=conn.prepareStatement(IQueryMapper.VIEWPLANS);
			s.executeUpdate();
			PreparedStatement sn=conn.prepareStatement(IQueryMapper.GENERATESEQUENCE);
			sn.executeUpdate();
		}
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new InvalidRequestException("Error in closing db connection");

			}
		
	}
}