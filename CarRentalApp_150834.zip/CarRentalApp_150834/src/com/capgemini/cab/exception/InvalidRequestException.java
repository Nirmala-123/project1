package com.capgemini.cab.exception;

public class InvalidRequestException extends Exception {
	private String msg;
	public InvalidRequestException()
	{
		
	}
	public InvalidRequestException(String msg)
	{
	this.msg=msg;
	}
	public String toString()
	{
		return this.msg;
	}


}
