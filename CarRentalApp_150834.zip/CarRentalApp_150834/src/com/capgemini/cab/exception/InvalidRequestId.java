package com.capgemini.cab.exception;

public class InvalidRequestId extends Exception{
	private String msg;
	public InvalidRequestId()
{
	
}
	public InvalidRequestId(String msg) {
		this.msg = msg;
	}
	public String toString()
	{
		return this.msg;
	}

}
