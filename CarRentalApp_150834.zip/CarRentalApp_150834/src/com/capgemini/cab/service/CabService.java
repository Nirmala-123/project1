package com.capgemini.cab.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.cabs.bean.*;
import com.capgemini.cab.dao.ICabRequestDAO;
import com.capgemini.cab.dao.CabRequestDAO;
import com.capgemini.cab.exception.InvalidRequestException;
import com.capgemini.cabs.bean.CabRequest;
import com.capgemini.cab.dao.*;
import com.capgemini.cab.exception.*;
import com.capgemini.cab.service.*;

public class CabService implements ICabService{
	public int addCabRequestDetails(CabRequest cabRequest) throws InvalidRequestException{
				ICabRequest s1=new ICabRequestDAO();
				private static String status;
			
				/*******************************************************************************************************
				- Function Name	:	addUserDetails(CabRequest b1)
				- Input Parameters	:	RechargeBean b1
				- Return Type		:	void
				- Throws			: 
				- Author			:	CAPGEMINI
				- Creation Date	:	20/06/2018
				- Description		:	add user to database by calling addUserDetails() method in dao
				********************************************************************************************************/
					@Override
					public int addCabRequestDetails(CabRequest b1) throws InvalidRequestException {
						ICabRequestDAO r=new CabRequestDAO();
						r.addCabRequestDetails(rb);
					
					}
					/*******************************************************************************************************
					- Function Name	    :	getReuestDetails(CabRequest b1)
					- Input Parameters	:	String requestId b1
					- Return Type		:	boolean
					- Throws			:   
					- Author			:	CAPGEMINI
					- Creation Date	    :	20/06/2018
					- Description		:	retrieve user details from  database by calling getReuestDetails() method in dao
					********************************************************************************************************/
					@Override
					public boolean getRequestDetails(String requestId,CabRequest  b1) throws InvalidRequestDetails {
					 ICabRequestDAO r=new CabRequestDAO();
						return r.getRequestDetails(rechId,b1);
						
					}
				
					/*******************************************************************************************************
					- Function Name 	:	isValidMobile(String mobileNum)
					- Input Parameters	:	String mobileNum
					- Return Type		:	boolean
					- Throws			:   
					- Author			:	CAPGEMINI
					- Creation Date	    :	20/06/2018
					- Description		:	Validate mobile number
					********************************************************************************************************/
					@Override
					public boolean isValidMobile(String mobileNum)
					{
						Pattern p=Pattern.compile("[0-9]{10}");
						Matcher m=p.matcher(mobileNum);
						return m.matches();
					}
					/*******************************************************************************************************
					- Function Name 	:	isValidName(String name)
					- Input Parameters	:	String name
					- Return Type		:	boolean
					- Throws			:   
					- Author			:	CAPGEMINI
					- Creation Date	    :	20/06/2018
					- Description		:	Validate name
					********************************************************************************************************/
					@Override
					public boolean isValidName(String name) {
						Pattern p=Pattern.compile("[A-Z][a-z]{2,}");
						Matcher m=p.matcher(name);
						return m.matches();
						
					}
					public boolean isValidPincode(String pincode)
					{
						Pattern p=Pattern.compile("[1-9]{1}[0-9]{5}");
						Matcher m=p.matcher(pincode);
						return m.matches();
					}
									
			
	}

}
