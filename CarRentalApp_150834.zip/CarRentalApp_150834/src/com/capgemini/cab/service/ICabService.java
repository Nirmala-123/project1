package com.capgemini.cab.service;

import com.capgemini.cab.exception.InvalidRequestException;
import com.capgemini.cabs.bean.*;


public interface ICabService {
	public int validPincode() throws InvalidRequestException;
	public int addCabRequest(CabRequest r) throws InvalidRequestException;
	boolean getRequestDetails(String requestId,CabRequest b1) throws InvalidRequestException;
	public boolean isValidMobile(String str);
	public boolean isValidName(String str);
	public boolean isValidPincode(CabRequest b1);
	

}
