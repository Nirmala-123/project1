package com.capgemini.cabs.bean;

public class CabRequest {
	private String CustomerName;
	private String CustomerMobileNum;
	private String userEmailId;
	private String AddressofPickup;
	private String requestStatus;
	private String requestId;
	private Long pincode;
	
	
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getCustomerMobileNum() {
		return CustomerMobileNum;
	}
	public void setCustomerMobileNum(String customerMobileNum) {
		CustomerMobileNum = customerMobileNum;
	}
	public String getUserEmailId() {
		return userEmailId;
	}
	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}
	public String getAddressofPickup() {
		return AddressofPickup;
	}
	public void setAddressofPickup(String addressofPickup) {
		AddressofPickup = addressofPickup;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public Long getPincode() {
		return pincode;
	}
	public void setPincode(Long pincode) {
		this.pincode = pincode;
	}
     
	public String toString()
	{
		return "Your Cab Request has been successfully registered, your request ID is: "+this.getRequestId()+"\nCustomer Name:"+this.CustomerName+"\nMobile number:"+this.CustomerMobileNum+"\nStatus:"+this.requestStatus+"\nPincode:"+this.pincode+"\nPickup Address:"+this.AddressofPickup;
	}
	

}
