package com.capgemini.cabs.ui;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.cabs.bean.*;
import com.capgemini.cab.exception.InvalidRequestException;
import com.capgemini.cab.dao.*;
import com.capgemini.cab.service.*;;


public class Client {

	public static void main(String[] args) {
		static Logger logger = Logger.getRootLogger();
		public static void main(String a[]) throws SQLException
		{	try {
			boolean retry=false;
			String mobileNum,name;
		    ICabService s1=new CabService();
		    CabRequest b1=new CabRequest();
			Scanner sc=new Scanner(System.in);
			do{
			System.out.println("Enter the name of the customer :");
			name=sc.next();
			}while(!s1.isValidName(name));
			b1.setUserName(name);
			do{
			System.out.println("Enter customer phone number:");
			mobileNum=sc.next();
			}while(!s1.isValidMobile(mobileNum));
			System.out.println("Enter Pick up Address: ");
			String pickupAdd=sc.next();
			b1.setCustomerMobileNum(mobileNum);
			s1.addUserDetails(b1);
			System.out.println(b1.getStatus());
			if(s1.isValidRecharge(b1))
			{
				System.out.println("Your Cab Request has been successfully registered, your request ID is:<"+b1.getrequestId()+">");
				logger.info("Accepted");
			}
			else
			{
				System.out.println("Your request details <"+b1.getRechId()+"> Check your status");
				logger.warn("Not Accepted");
			}
			do{
			System.out.println("To check your details enter your recharge Id :");
			String rech=sc.next();
			retry=s1.retrieveUserDetails(rech,b1);
			System.out.println(b1);
			}while(retry);
		}
		catch(InputMismatchException e)
		{
			logger.error("Exception Occured"+e);
			System.out.println(e);
		}
		catch(ClassCastException ce)
		{
			logger.error("Exception Occured"+ce);
			System.out.println(ce);
		}
		catch(NullPointerException npe)
		{
			logger.error("Exception Occured"+npe);
			System.out.println(npe);
		}
		catch(InvalidRecharge ir)
		{
			logger.error("Exception Occured"+ir);
			System.out.println(ir);
		}
		}
	}

}
