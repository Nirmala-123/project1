package com.ebill.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ebill.pojo.BillBean;

/**
 * Servlet implementation class BillCalculation
 */
@WebServlet("/BillCalculation")
public class BillCalculation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BillCalculation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		ServletContext context = request.getServletContext();
		BillBean bean = (BillBean) request.getAttribute("consDetails");
		if(bean.getCurrReading() >= bean.getLstReading() ){
			float unitConsumed = bean.getCurrReading() - bean.getLstReading();
			float netAmount = unitConsumed * 1.15f + 100f;
			bean.setUnitConsumed(unitConsumed);
			bean.setNetAmount(netAmount);
			request.setAttribute("insertConsDetails", bean);
			getServletContext().getRequestDispatcher("/DBServlet").forward(request, response);
		}
		else
		{
			context.setAttribute("Status", "Current Month Reading must be greater than Last Month Reading");
			response.sendRedirect("Status");
		}
	}

}
