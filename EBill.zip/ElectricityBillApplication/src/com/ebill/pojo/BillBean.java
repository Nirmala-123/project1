package com.ebill.pojo;

public class BillBean {
	private int billNo;
	private long consNum;
	private String consName;
	private float unitConsumed;
	private float netAmount;
	private float currReading;
	private float lstReading;
	
	public float getLstReading() {
		return lstReading;
	}
	public void setLstReading(float lstReading) {
		this.lstReading = lstReading;
	}
	public float getCurrReading() {
		return currReading;
	}
	public void setCurrReading(float currReading) {
		this.currReading = currReading;
	}
	public int getBillNo() {
		return billNo;
	}
	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}
	public long getConsNum() {
		return consNum;
	}
	public void setConsNum(long d) {
		this.consNum = d;
	}
	public String getConsName() {
		return consName;
	}
	public void setConsName(String consName) {
		this.consName = consName;
	}
	public float getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(float unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public float getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(float netAmount) {
		this.netAmount = netAmount;
	}
}
