package com.ebill.DBServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.ebill.pojo.BillBean;

/**
 * Servlet implementation class ConsumerDetails
 */
@WebServlet("/ConsumerDetails")
public class ConsumerDetails extends HttpServlet {
	@Resource(lookup="java:/OracleDS")
	DataSource ds;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConsumerDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		ServletContext context = request.getServletContext();
		double consNum = (double) request.getAttribute("consNum");
		float lstReading = (float) request.getAttribute("lstReading");
		float currReading = (float) request.getAttribute("currReading");
		BillBean bean = null;
		try {
			Connection connection = ds.getConnection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			preparedStatement=connection.prepareStatement("SELECT consumer_num,consumer_name,address FROM consumers where consumer_num = ?");
			preparedStatement.setDouble(1, consNum);
			
			resultSet=preparedStatement.executeQuery();
			//connection.commit();		
			if(resultSet.next()){
				bean = new BillBean();
				bean.setConsNum(resultSet.getLong(1));
				bean.setConsName(resultSet.getString(2));
				bean.setCurrReading(currReading);
				bean.setLstReading(lstReading);
				request.setAttribute("consDetails", bean);
				context.getRequestDispatcher("/BillCalculation").forward(request, response);
			}
			else
			{
				context.setAttribute("Status", "Invalid Consumer Number");
				response.sendRedirect("Status");
			}
		}		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
