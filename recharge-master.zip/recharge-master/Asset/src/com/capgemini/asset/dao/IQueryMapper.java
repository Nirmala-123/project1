package com.capgemini.asset.dao;

public interface IQueryMapper {
public final static String RETRIEVE_USER_DATA="select * from usermaster";
}
