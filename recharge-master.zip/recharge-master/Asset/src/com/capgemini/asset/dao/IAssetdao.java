package com.capgemini.asset.dao;

import com.capgemini.asset.bean.AssetBean;

public interface IAssetdao {
	public boolean dataAuthentication(AssetBean a);
	
}
