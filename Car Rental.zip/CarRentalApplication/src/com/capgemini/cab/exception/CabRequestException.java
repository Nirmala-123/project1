package com.capgemini.cab.exception;

public class CabRequestException extends Exception {
public CabRequestException()
{
	
}
public CabRequestException(String msg)
{
	super(msg);
}
}
