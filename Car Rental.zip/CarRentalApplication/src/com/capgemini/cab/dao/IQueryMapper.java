package com.capgemini.cab.dao;

public interface IQueryMapper {
public static final String CHECKTABLE="SELECT COUNT(tname) FROM TAB WHERE tname='CAB_REQUEST'";
public static final String CREATETABLE ="CREATE TABLE cab_request(request_id NUMBER,customer_name VARCHAR2(20),phone_number VARCHAR2(10),date_of_request DATE,request_status VARCHAR2(12),cab_number VARCHAR2(15),address_of_pickup VARCHAR2(50),pincode VARCHAR2(6))";
public static final String SEQUENCECREATION = "CREATE SEQUENCE seq_request_id START WITH 1001";
public static final String GENERTESEQUENCE = "SELECT seq_request_id.NEXTVAL FROM DUAL";
public static final String INSERTQUERY = "INSERT INTO cab_request values(?,?,?,SYSDATE,?,?,?,?)";
public static final String CHECKREQID ="SELECT COUNT(request_id) FROM cab_request WHERE request_id=?";
public static final String GETDETAILS = "SELECT customer_name,request_status,cab_number FROM cab_request WHERE request_id=?";

}
